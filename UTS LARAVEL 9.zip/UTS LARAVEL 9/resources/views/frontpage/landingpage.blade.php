<x-home-layout class>
<main>
        <div>          
                <div>
                    <nav class="flex items-center justify-center flex-wrap p-2">
                        <div class="flex items-center flex-no-shrink text-black">
                            <div class="hover: scale-105 transition-transform">
                            <a href="./landingPage.html">
                                <div class="text-s font-bold flex justify-center text-center">
                                    BRAHMA VIHARA ARAMA
                                </div>  
                            </a>
                            <span class="font-semibold text-xl tracking-tight uppercase"></span>
                        </div>
                        </div>
                    </nav>
                </div>
            
            <div class=" text-black p-4">
                <div>
                <div class="text-4xl font-bold flex justify-center text-center">
                    OUR SERVICES
                </div>
              </div>  
            </div>
                
            <div class="flex items-center justify-center content-center p-3">
                <div class="space-y-2 py-3">
                    <div class="flex gap-3 flex-row max-md:flex-col">
                       
                        <div class="max-w-sm rounded-md overflow-hidden shadow-2xl bg-white  hover:scale-105 transition-transform ">
                            <a href="">
                            <img class="w-full " src="https://media-cdn.tripadvisor.com/media/photo-s/18/30/4f/e9/the-pond-inside-the-vihara.jpg">
                            <div class="px-6 py-4">
                            <div class="font-bold text-xl mb-2 text-black text-center">VIHARA ARAMA</div>
                            <p class="text-gray-700 text-base">
                                1 Adult
                            </p>
                            <p class="text-gray-700 text-base font-semibold">
                                Rp. 50.000
                            </p>
                            </div>
                            </a>
                        </div>
                        <div class="max-w-sm rounded-md overflow-hidden shadow-2xl bg-white  hover:scale-105 transition-transform">
                            <a href="">
                            <img class="w-full" src="https://1.bp.blogspot.com/-b9vRHzSQ3IM/XkFSZiTe3YI/AAAAAAABJes/uFFF7RwC4MY0z_MMAITeoSvTyMrkHy2pACKgBGAsYHg/s1600/IMG-20190619-WA0059.jpg">
                            <div class="px-6 py-4">
                            <div class="font-bold text-xl mb-2 text-black text-center">VIHARA ARAMA WITH FAMILY #1
                            </div>
                            <p class="text-gray-700 text-base">
                                2 Adult, 2 Child
                            </p>
                            <p class="text-gray-700 text-base font-semibold">
                                Rp. 150.000
                            </p>
                            </div>
                            </a>
                        </div>
                        <div class="max-w-sm rounded-md overflow-hidden shadow-2xl bg-white  hover:scale-105 transition-transform">
                            <a href="">
                            <img class="w-full" src="https://1.bp.blogspot.com/-66g6vt5NTk4/WIhsucI1qHI/AAAAAAAAPs4/jZVztd3MUfU9EJluZpnYo-L16LywqpjfQCLcB/s1600/wihara.jpg">
                            <div class="px-6 py-4">
                            <div class="font-bold text-xl mb-2 text-black text-center">VIHARA ARAMA WITH FAMILY #2</div>
                            <p class="text-gray-700 text-base">
                               2 Adult, 2 Child (Include Hotel)
                            </p>
                            <p class="text-gray-700 text-base font-semibold">
                                Rp. 450.000
                            </p>
                            </div>
                            </a>
                        </div>
                    
                    </div>
                        <div class="flex justify-center">
                            <div class="max-w-sm rounded-md overflow-hidden bg-white">
                                <div class="px-6 py-4">
                                <div class="font-bold text-xl mb-2 text-black text-center">SHOPPING CART</div>
                                
                                <div class="flex justify-start">
                                <p class="text-gray-700 text-base text-center">
                                    Your Purchase:
                                </p>
                                </div>
                                <div class="flex justify-start">
                                <p class="text-gray-700 text-lg text-center font-bold">
                                    Total Purchase:
                                </p>
                                </div>
                                <div class="py-5 flex items-center justify-center">
                                    <a href="./ticketPage.html">
                                        <button id="tiket" class="bg-indigo-500 w-52 text-white font-semibold py-2 rounded-full hover:bg-indigo-800 transition-colors">Checkout</button>
                                    </a>
                                </div>
                                </div>
                                
                            </div>
                        </div>

                       
                    
                </div>
            </div>
        </div>
    </main>
</x-home-layout>