<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INTEGER #4</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="./css/style.css">
</head>
<body class="bg-indigo-700">
    <main class="bg-indigo-700">
        <div class="h-screen">
            
            <div>
                <nav class="flex items-center justify-center flex-wrap p-6">
                    <div class="flex items-center flex-no-shrink text-white">
                        <a href="./landingPage.html">
                            <img class="h-14" src="./asset/logoInteger.png">
                        </img>
                        </a>
                        <span class="font-semibold text-xl tracking-tight uppercase"></span>
                    </div>
                </nav>
            </div>
            
            <div>
                <!--landing-->
                <?php echo $__env->yieldContent('content'); ?>
            </div>   
            
            </div>
            
        </div>
    </main>
</body>
</html><?php /**PATH D:\KULIAH\Lara_Breeze\LBreeze\resources\views/layouts/home-layout.blade.php ENDPATH**/ ?>