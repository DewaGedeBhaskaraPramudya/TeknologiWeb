
<?php $__env->startSection('content'); ?>
<div class="content-center flex items-center justify-center text-white p-44 space-y-2 gap-y-3">
                <div class="text-center">
                
                <div class="text-l flex justify-center flex-col">
                    INTEGER #4
                </div>
                <div class="text-5xl font-bold flex justify-center">
                    MALAM GELAR SENI
                </div>
                <div class="text-sm text-slate-200 flex justify-center">
                    See your favourite Band on November 5 2022.
                </div>
                <div class="py-5">
                    <a href="<?php echo e(url('artistpage')); ?>">
                    <button id="seeMore" class="bg-indigo-500 w-full text-white font-semibold py-2 rounded-full hover:bg-indigo-800 transition-colors">See More</button>
                    </a>
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\Lara_Breeze\LBreeze\resources\views/landing-layout.blade.php ENDPATH**/ ?>