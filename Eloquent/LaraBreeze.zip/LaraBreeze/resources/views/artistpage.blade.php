@extends('home-layout')
@section('content')
<div>          
                <div>
                    <nav class="flex items-center justify-center flex-wrap p-6">
                        <div class="flex items-center flex-no-shrink text-white">
                            <div class="hover: scale-105 transition-transform">
                            <a href="./landingPage.html">
                                <img class="h-14" src="./asset/logoInteger.png">
                            </img>
                            </a>
                            <span class="font-semibold text-xl tracking-tight uppercase"></span>
                        </div>
                        </div>
                    </nav>
                </div>
            
            <div class=" text-white p-4">
                <div>
                <div class="text-4xl font-bold flex justify-center text-center">
                    GUEST STAR
                </div>
              </div>  
            </div>
                
            <div class="flex items-center justify-center content-center p-3">
                <div class="space-y-2 py-3">
                    <div class="flex gap-3 flex-row max-md:flex-col">
                       
                        <div class="max-w-sm rounded-md overflow-hidden shadow-slate-900 bg-white  hover:scale-105 transition-transform ">
                            <a href="https://www.youtube.com/c/PeeWeeGaskinsTV">
                            <img class="w-full " src="./asset/pee_wee.jpg">
                            <div class="px-6 py-4">
                            <div class="font-bold text-xl mb-2 text-black text-center">Pee Wee Gaskins</div>
                            <p class="text-gray-700 text-base">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil.
                            </p>
                            </div>
                            </a>
                        </div>
                        <div class="max-w-sm rounded-md overflow-hidden shadow-2xl bg-white  hover:scale-105 transition-transform">
                            <a href="https://www.youtube.com/channel/UC_XudFp1mYAFUAom-mN5pCQ">
                            <img class="w-full" src="./asset/harmonia.jpg">
                            <div class="px-6 py-4">
                            <div class="font-bold text-xl mb-2 text-black text-center">HarmoniA</div>
                            <p class="text-gray-700 text-base">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil.
                            </p>
                            </div>
                            </a>
                        </div>
                        <div class="max-w-sm rounded-md overflow-hidden shadow-2xl bg-white  hover:scale-105 transition-transform">
                            <a href="https://www.youtube.com/c/NotSoKoplo">
                            <img class="w-full" src="./asset/notsokoplo.jpg">
                            <div class="px-6 py-4">
                            <div class="font-bold text-xl mb-2 text-black text-center">Not So Koplo</div>
                            <p class="text-gray-700 text-base">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil.
                            </p>
                            </div>
                            </a>
                        </div>
                    
                    </div>
                        <div class="py-5 flex items-center justify-center">
                            <a href="{{url('login-page')}}">
                            <button id="tiket" class="bg-indigo-500 w-52 text-white font-semibold py-2 rounded-full hover:bg-indigo-800 transition-colors">Buy Ticket</button>
                            </a>
                        </div>
                    
                </div>
            </div>
        </div>
</div>
@endsection