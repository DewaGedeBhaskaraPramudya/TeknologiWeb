@extends('home-layout')
@section('content')
<div class="bg-indigo-700">          
                <div>
                    <nav class="  p-6">
                        <div class="flex items-center justify-center flex-nowrap">
                        <div class="flex items-center flex-no-shrink text-white">
                            <a href="./landingPage.html">
                                <img class="h-14" src="./asset/logoInteger.png">
                            </img>
                            </a>
                        </div>
                        </div>
                    </nav>
                </div>
            
            <div class=" text-white p-4">
                <div>
                <div class="text-4xl font-bold flex justify-center text-center">
                    BUY YOUR TICKET NOW!
                </div>
                <div class="py-5 font-bold text-xl mb-2 text-white text-center">Ticket Information</div>
              </div>  
            </div>
                
            <div class="flex items-center justify-center content-center">
                <div class="flex flex-row">
                <div class="space-y-2 py-3">
                    <div class="max-w-sm rounded-md overflow-hidden shadow-lg bg-white  hover:scale-110 transition-transform">
                        <div class="px-6 py-4">
                        <div class="font-bold text-xl mb-2 text-gray-700 text-center">Presale 1</div>
                        <p class="text-gray-700 text-base text-center">
                            September 24 - October 4
                        </p>
                        <p class="text-gray-700 text-lg text-center font-bold">
                            IDR. 40.000
                        </p>
                        <div class="bg-red-600 text-white rounded-lg text-center font-semibold">
                            Not Available
                        </div>
                        </div>
                    </div>

                    <div class="space-y-2 py-3">
                        <div class="max-w-sm rounded-md overflow-hidden shadow-lg bg-white  hover:scale-110 transition-transform">
                            <div class="px-6 py-4">
                            <div class="font-bold text-xl mb-2 text-black text-center">Presale 2</div>
                            <p class="text-gray-700 text-base text-center">
                                October 5 - November 2
                            </p>
                            <p class="text-gray-700 text-lg text-center font-bold">
                                IDR. 50.000
                            </p>
                            <div class="bg-green-600 text-white rounded-lg text-center font-semibold
                            ">
                                Available
                            </div>
                            </div>
                        </div>

                        <div class="space-y-2 py-3">
                            <div class="max-w-sm rounded-md overflow-hidden shadow-lg bg-white  hover:scale-110 transition-transform">
                                <div class="px-6 py-4">
                                <div class="font-bold text-xl mb-2 text-gray-700 text-center">On The Spot</div>
                                <p class="text-gray-700 text-base text-center">
                                    November 5
                                </p>
                                <p class="text-gray-700 text-lg text-center font-bold">
                                    IDR. 100.000
                                </p>
                                <div class="bg-red-600 text-white rounded-lg text-center font-semibold">
                                    Not Available
                                </div>
                                <p class="text-gray-700 text-sm text-center font-semibold">
                                    Only available on mentioned date.
                                </p>
                                </div>
                            </div>

                    <div class="py-4">
                        <div class="flex flex-col gap-2">
                            <a href="./contactPage.html">
                            <button id="seeMore" class="bg-green-600 w-full text-white font-semibold py-2 rounded-full hover:bg-green-700 transition-colors">Buy Now!</button>
                            </a>
                            <a href="artistpage">
                                <button id="seeMore" class="py-2 w-full text-white font-semibold rounded-full hover:bg-indigo-800 transition-colors hover:underline">Go Back</button>
                            </a>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
</div>
@endsection